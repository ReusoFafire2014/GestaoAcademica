AmplifyJS 1.1.2
http://amplifyjs.com
Developed & Maintained by http://appendto.com

For the full source code of AmplifyJS, please visit https://github.com/appendto/amplify/tree/1.1.2